package com.codinginflow.klfocus;

public class attendance {
    private String id;

    public attendance() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}
