package com.example.splashliter;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

public class extras extends AppCompatActivity {
 TextView textView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_extras);

        Bundle bundle = getIntent().getExtras();

        if(bundle.getString("STRING_I_NEED")!= null)
        {
            Toast.makeText(extras.this,bundle.getString("STRING_I_NEED"),Toast.LENGTH_LONG).show();
        }
        }

    }


